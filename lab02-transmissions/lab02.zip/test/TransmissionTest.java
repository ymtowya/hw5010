import static org.junit.Assert.assertEquals;

import org.junit.Before;
import org.junit.Test;

/**
 * Test case for Transmission Class.
 *
 */
public class TransmissionTest {

  /**
   * Set up the instance.
   * 
   * @throws java.lang.Exception when input is invalid
   */
  @Before
  public void setUp() throws IllegalArgumentException {
  }

  @Test
  public final void test() {
    assertEquals(0, 0);
  }

}
